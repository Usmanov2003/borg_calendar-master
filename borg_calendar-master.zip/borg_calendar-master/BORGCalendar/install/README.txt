Installers are now created using jpackage. IzPack is no longer used.

Installers need to be created manually by running either winpackage.bat on windows or linpackage.sh on linux.

A tar or zip can be created from the contents of target/installer for other OSes, like MAC.

** The installers bundle Java. A tar or ZIP does not.
