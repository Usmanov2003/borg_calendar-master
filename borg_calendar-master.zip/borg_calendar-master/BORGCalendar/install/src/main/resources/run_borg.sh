cd "%{INSTALL_PATH}"
jre/bin/java -Xmx128m -XX:MinHeapFreeRatio=10 -XX:MaxHeapFreeRatio=20 -Xms24m -jar borg.jar